package com.zhiwu.olympiadtutor.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.zhiwu.olympiadtutor.data.*
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.roundToInt

private enum class Screen { HOME, LIBRARY, PRACTICE, PROGRESS, PACKS, TUTOR, RESULT }

@Composable
fun OlympiadApp(
    repository: OlympiadRepository,
    importer: ContentPackImporter,
) {
    val questions by repository.questions.collectAsState(initial = emptyList())
    val tutorQuestions by repository.tutorQuestions.collectAsState(initial = emptyList())
    val packs by repository.packs.collectAsState(initial = emptyList())
    val attempts by repository.attempts.collectAsState(initial = emptyList())
    val mastery by repository.mastery.collectAsState(initial = emptyList())

    var screen by remember { mutableStateOf(Screen.HOME) }
    var selectedQuestion by remember { mutableStateOf<QuestionEntity?>(null) }
    var resultScore by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }

    MaterialTheme {
        Scaffold(
            bottomBar = {
                if (screen !in listOf(Screen.TUTOR, Screen.RESULT)) {
                    NavigationBar {
                        listOf(
                            Triple(Screen.HOME, "首页", "⌂"),
                            Triple(Screen.LIBRARY, "题库", "▦"),
                            Triple(Screen.PRACTICE, "练习", "◎"),
                            Triple(Screen.PROGRESS, "记录", "◒"),
                            Triple(Screen.PACKS, "题库管理", "↓"),
                        ).forEach { (target, label, symbol) ->
                            NavigationBarItem(
                                selected = screen == target,
                                onClick = { screen = target },
                                icon = { Text(symbol) },
                                label = { Text(label) },
                            )
                        }
                    }
                }
            },
            topBar = {
                if (screen !in listOf(Screen.TUTOR, Screen.RESULT)) {
                    Surface(shadowElevation = 1.dp) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .statusBarsPadding()
                                .padding(horizontal = 18.dp, vertical = 14.dp)
                        ) {
                            Text(
                                text = when (screen) {
                                    Screen.HOME -> "奥数思路训练"
                                    Screen.LIBRARY -> "题库"
                                    Screen.PRACTICE -> "智能练习"
                                    Screen.PROGRESS -> "学习记录"
                                    Screen.PACKS -> "题库管理"
                                    else -> ""
                                },
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "原生手机版 v0.2 · Canonical Runtime",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        ) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        total = questions.size,
                        tutorReady = tutorQuestions.size,
                        attempts = attempts.size,
                        onStart = {
                            val q = pickSmart(tutorQuestions, mastery)
                            if (q != null) {
                                selectedQuestion = q
                                screen = Screen.TUTOR
                            } else message = "当前没有可训练的 Tutor Ready 题目"
                        },
                        onLibrary = { screen = Screen.LIBRARY },
                        onPacks = { screen = Screen.PACKS },
                    )
                    Screen.LIBRARY -> LibraryScreen(
                        questions = questions,
                        onQuestion = { q ->
                            if (q.tier == "tutor") {
                                selectedQuestion = q
                                screen = Screen.TUTOR
                            } else {
                                message = "这道题已进入结构化题库，但 ReasoningGraph 尚未审核完成。"
                            }
                        }
                    )
                    Screen.PRACTICE -> PracticeScreen(
                        tutorCount = tutorQuestions.size,
                        mastery = mastery,
                        onStart = {
                            val q = pickSmart(tutorQuestions, mastery)
                            if (q != null) {
                                selectedQuestion = q
                                screen = Screen.TUTOR
                            } else message = "暂无可训练题目"
                        }
                    )
                    Screen.PROGRESS -> ProgressScreen(attempts, mastery)
                    Screen.PACKS -> PackManagerScreen(
                        packs = packs,
                        importer = importer,
                        onMessage = { message = it },
                    )
                    Screen.TUTOR -> selectedQuestion?.let { q ->
                        TutorScreen(
                            question = q,
                            repository = repository,
                            onExit = { screen = Screen.HOME },
                            onFinished = { score ->
                                resultScore = score
                                screen = Screen.RESULT
                            }
                        )
                    }
                    Screen.RESULT -> selectedQuestion?.let { q ->
                        ResultScreen(
                            question = q,
                            score = resultScore,
                            onAgain = { screen = Screen.TUTOR },
                            onHome = { screen = Screen.HOME },
                        )
                    }
                }

                message?.let {
                    Surface(
                        color = MaterialTheme.colorScheme.inverseSurface,
                        contentColor = MaterialTheme.colorScheme.inverseOnSurface,
                        shape = RoundedCornerShape(14.dp),
                        shadowElevation = 6.dp,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(18.dp)
                            .clickable { message = null }
                    ) {
                        Text(
                            it,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }
}

private fun pickSmart(
    questions: List<QuestionEntity>,
    mastery: List<MasteryEntity>,
): QuestionEntity? {
    if (questions.isEmpty()) return null
    val scores = mastery.associate { it.family to it.score }
    return questions.minByOrNull { scores[it.family] ?: -1.0 }
}

@Composable
private fun HomeScreen(
    total: Int,
    tutorReady: Int,
    attempts: Int,
    onStart: () -> Unit,
    onLibrary: () -> Unit,
    onPacks: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("今天先练“怎么想”", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "一道题，一次只推进一个推理节点",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "答错时停留当前步骤；答对后才进入下一步。题库内容与 App 解耦，可通过 .olympiadpack 持续更新。",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                        Text("开始思路训练")
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("题库", total.toString(), Modifier.weight(1f))
                StatCard("完整思路", tutorReady.toString(), Modifier.weight(1f))
                StatCard("已练习", attempts.toString(), Modifier.weight(1f))
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("题库浏览", "查看所有已导入题目", onLibrary, Modifier.weight(1f))
                ActionCard("导入题库", "导入 .olympiadpack", onPacks, Modifier.weight(1f))
            }
        }

        item {
            ElevatedCard(shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("当前数据分层", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text("Tutor Ready：可进入完整分步思路训练")
                    Text("Structured：已入库并完成结构标注，但 ReasoningGraph 尚待审核")
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "后续新增十几本书只需要更新题库包，不必重新安装 App。",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    ElevatedCard(modifier, shape = RoundedCornerShape(18.dp)) {
        Column(
            Modifier.padding(vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun ActionCard(
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    ElevatedCard(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(17.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun LibraryScreen(
    questions: List<QuestionEntity>,
    onQuestion: (QuestionEntity) -> Unit,
) {
    var filter by remember { mutableStateOf("全部") }
    val visible = when (filter) {
        "Tutor Ready" -> questions.filter { it.tier == "tutor" }
        "Structured" -> questions.filter { it.tier != "tutor" }
        else -> questions
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("共 ${visible.size} 道", style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                listOf("全部", "Tutor Ready", "Structured").forEach { item ->
                    FilterChip(
                        selected = filter == item,
                        onClick = { filter = item },
                        label = { Text(item) }
                    )
                }
            }
        }

        items(visible, key = { it.id }) { q ->
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onQuestion(q) },
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            q.source,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (q.tier == "tutor") "完整思路" else "已结构化",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (q.tier == "tutor") MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(q.title, style = MaterialTheme.typography.bodyLarge)
                    Spacer(Modifier.height(9.dp))
                    Text(
                        "${q.family} · ${q.strategy.ifBlank { "策略待完善" }} · ${q.difficulty}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun PracticeScreen(
    tutorCount: Int,
    mastery: List<MasteryEntity>,
    onStart: () -> Unit,
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("SMART PRACTICE", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "优先训练掌握度较低的题目结构",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(Modifier.height(8.dp))
                    Text("当前有 $tutorCount 道 Tutor Ready 题目可进入完整思路训练。")
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                        Text("开始智能练习")
                    }
                }
            }
        }
        if (mastery.isNotEmpty()) {
            item { Text("当前优先薄弱结构", fontWeight = FontWeight.Bold) }
            items(mastery.take(5)) { MasteryRow(it) }
        }
    }
}

@Composable
private fun ProgressScreen(
    attempts: List<AttemptEntity>,
    mastery: List<MasteryEntity>,
) {
    val average = if (attempts.isEmpty()) 0 else attempts.map { it.score }.average().roundToInt()
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("完成题目", attempts.size.toString(), Modifier.weight(1f))
                StatCard("平均节点分", average.toString(), Modifier.weight(1f))
            }
        }
        item { Text("Problem Family 掌握度", fontWeight = FontWeight.Bold) }
        if (mastery.isEmpty()) {
            item {
                ElevatedCard(shape = RoundedCornerShape(18.dp)) {
                    Text(
                        "完成几道 Tutor Ready 题目后，这里会记录结构掌握度。",
                        modifier = Modifier.padding(18.dp)
                    )
                }
            }
        } else {
            items(mastery) { MasteryRow(it) }
        }
        item {
            Text(
                "当前掌握度使用 MVP 加权更新规则，仅用于测试个性化练习闭环，后续会用真实答题数据校准。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MasteryRow(item: MasteryEntity) {
    ElevatedCard(shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(15.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(item.family, fontWeight = FontWeight.Medium)
                Text("${item.score.roundToInt()}%")
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (item.score / 100.0).toFloat() },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(5.dp))
            Text(
                "证据 ${item.evidenceCount} 次",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun PackManagerScreen(
    packs: List<ContentPackEntity>,
    importer: ContentPackImporter,
    onMessage: (String) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var importing by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            importing = true
            scope.launch {
                val result = runCatching { importer.importUri(uri) }
                importing = false
                result.onSuccess {
                    onMessage("已导入 ${it.title}：${it.questionCount} 道，其中完整思路 ${it.tutorReadyCount} 道")
                }.onFailure {
                    onMessage("导入失败：${it.message ?: "未知错误"}")
                }
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            ElevatedCard(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text("导入题库包", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        ".olympiadpack 是 ZIP 容器，包含 manifest.json 与 questions.json。导入时先校验 Schema，再在一个 Room transaction 中写入。",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(14.dp))
                    Button(
                        onClick = { launcher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                        enabled = !importing,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (importing) "正在导入…" else "选择 .olympiadpack")
                    }
                }
            }
        }

        item { Text("已安装题库", fontWeight = FontWeight.Bold) }

        if (packs.isEmpty()) {
            item { Text("正在初始化内置 Starter Pack…") }
        } else {
            items(packs, key = { it.bundleId }) { pack ->
                ElevatedCard(shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text(pack.title, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text("版本 ${pack.bundleVersion} · Schema ${pack.schemaVersion}")
                        Text("Ontology ${pack.ontologyVersion}")
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "共 ${pack.questionCount} 道 · Tutor Ready ${pack.tutorReadyCount} 道",
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        item {
            Text(
                "同一 bundle_id 再次导入时会原子替换内容题库，但不会清除学生 attempts 与 mastery。正式版会继续加入 content_version 和更细粒度迁移。",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun TutorScreen(
    question: QuestionEntity,
    repository: OlympiadRepository,
    onExit: () -> Unit,
    onFinished: (Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var nodes by remember(question.id) { mutableStateOf<List<ReasoningNodeEntity>>(emptyList()) }
    var loading by remember(question.id) { mutableStateOf(true) }

    LaunchedEffect(question.id) {
        nodes = repository.nodes(question.id)
        loading = false
    }

    if (loading) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    if (nodes.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("ReasoningGraph 尚未就绪") }
        return
    }

    var index by remember(question.id) { mutableIntStateOf(0) }
    val wrongNodes = remember(question.id) { mutableStateListOf<Int>() }
    var selected by remember { mutableStateOf<Int?>(null) }
    var answer1 by remember { mutableStateOf("") }
    var answer2 by remember { mutableStateOf("") }
    var feedback by remember { mutableStateOf<String?>(null) }
    var correct by remember { mutableStateOf(false) }
    var hintVisible by remember { mutableStateOf(false) }

    LaunchedEffect(index) {
        selected = null
        answer1 = ""
        answer2 = ""
        feedback = null
        correct = false
        hintVisible = false
    }

    val node = nodes[index]
    val payload = remember(node.payloadJson) { JSONObject(node.payloadJson) }
    val progress = (index + 1).toFloat() / nodes.size.toFloat()

    Scaffold(
        topBar = {
            Surface(shadowElevation = 1.dp) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onExit) { Text("退出") }
                    Column(Modifier.weight(1f)) {
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                        Text("思考步骤 ${index + 1} / ${nodes.size}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ElevatedCard(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(17.dp)) {
                        Text(
                            "${question.source} · ${question.family}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(question.title, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            item {
                ElevatedCard(shape = RoundedCornerShape(22.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(
                            "AI 导师 · 当前只解决一步",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(node.prompt, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(14.dp))

                        when (node.type) {
                            "choice" -> {
                                val options = payload.getJSONArray("options")
                                for (i in 0 until options.length()) {
                                    val isSelected = selected == i
                                    OutlinedButton(
                                        onClick = { if (!correct) selected = i },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = if (isSelected) ButtonDefaults.outlinedButtonColors(
                                            containerColor = MaterialTheme.colorScheme.primaryContainer
                                        ) else ButtonDefaults.outlinedButtonColors()
                                    ) {
                                        Text("${('A'.code + i).toChar()}. ${options.getString(i)}")
                                    }
                                    Spacer(Modifier.height(7.dp))
                                }
                            }
                            "number" -> {
                                OutlinedTextField(
                                    value = answer1,
                                    onValueChange = { if (!correct) answer1 = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("输入答案") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true
                                )
                            }
                            "pair" -> {
                                val placeholders = payload.optJSONArray("placeholders")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = answer1,
                                        onValueChange = { if (!correct) answer1 = it },
                                        modifier = Modifier.weight(1f),
                                        label = { Text(placeholders?.optString(0) ?: "答案1") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        singleLine = true
                                    )
                                    OutlinedTextField(
                                        value = answer2,
                                        onValueChange = { if (!correct) answer2 = it },
                                        modifier = Modifier.weight(1f),
                                        label = { Text(placeholders?.optString(1) ?: "答案2") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                        singleLine = true
                                    )
                                }
                            }
                            "boolean" -> {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("正确", "错误").forEachIndexed { i, label ->
                                        FilterChip(
                                            selected = selected == i,
                                            onClick = { if (!correct) selected = i },
                                            label = { Text(label) }
                                        )
                                    }
                                }
                            }
                        }

                        feedback?.let {
                            Spacer(Modifier.height(12.dp))
                            Surface(
                                color = if (correct) MaterialTheme.colorScheme.primaryContainer
                                else MaterialTheme.colorScheme.errorContainer,
                                shape = RoundedCornerShape(13.dp)
                            ) { Text(it, modifier = Modifier.padding(12.dp)) }
                        }

                        if (hintVisible && node.hint.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.tertiaryContainer,
                                shape = RoundedCornerShape(13.dp)
                            ) { Text("提示：${node.hint}", modifier = Modifier.padding(12.dp)) }
                        }

                        Spacer(Modifier.height(14.dp))
                        Button(
                            onClick = {
                                if (correct) {
                                    if (index == nodes.lastIndex) {
                                        val score = ((nodes.size - wrongNodes.distinct().size).toDouble() / nodes.size * 100.0).roundToInt()
                                        scope.launch {
                                            repository.recordAttempt(question, score)
                                            onFinished(score)
                                        }
                                    } else index++
                                } else {
                                    val isCorrect = evaluateNode(
                                        type = node.type,
                                        payload = payload,
                                        selected = selected,
                                        answer1 = answer1,
                                        answer2 = answer2,
                                    )
                                    if (isCorrect) {
                                        correct = true
                                        feedback = node.feedback.ifBlank { "正确，可以进入下一步。" }
                                    } else {
                                        if (!wrongNodes.contains(index)) wrongNodes.add(index)
                                        feedback = "这一步还不对。系统会停留在当前节点，不会自动跳到下一步。"
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (correct) {
                                if (index == nodes.lastIndex) "完成本题" else "下一步"
                            } else "确认这一步")
                        }

                        if (!correct) {
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { hintVisible = true },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("给我一个提示") }
                        }
                    }
                }
            }

            item {
                Text(
                    "最终答案不会提前显示。TutorEngine 的推进条件只来自明确提交并判定正确的完整回答。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

private fun normalizeAnswer(value: String): String =
    value.trim().replace(" ", "").replace("，", ",").replace("。", "")

private fun evaluateNode(
    type: String,
    payload: JSONObject,
    selected: Int?,
    answer1: String,
    answer2: String,
): Boolean = when (type) {
    "choice" -> selected != null && selected == payload.getInt("correctIndex")
    "number" -> normalizeAnswer(answer1) == normalizeAnswer(payload.getString("answer"))
    "pair" -> {
        val answers = payload.getJSONArray("answers")
        normalizeAnswer(answer1) == normalizeAnswer(answers.getString(0)) &&
            normalizeAnswer(answer2) == normalizeAnswer(answers.getString(1))
    }
    "boolean" -> {
        val expected = payload.optBoolean("answer")
        val value = when (selected) { 0 -> true; 1 -> false; else -> null }
        value == expected
    }
    else -> false
}

@Composable
private fun ResultScreen(
    question: QuestionEntity,
    score: Int,
    onAgain: () -> Unit,
    onHome: () -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().statusBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(28.dp))
        Text("本题思路完成", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Surface(shape = RoundedCornerShape(60.dp), color = MaterialTheme.colorScheme.primaryContainer) {
            Box(Modifier.size(116.dp), contentAlignment = Alignment.Center) {
                Text(score.toString(), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text(question.family, color = MaterialTheme.colorScheme.primary)
        Text(
            "这个分数表示本次各推理节点的首次作答表现，不只是最终答案。",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(20.dp))
        ElevatedCard(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(17.dp)) {
                Text("本题答案", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text(question.answer)
                Spacer(Modifier.height(10.dp))
                Text("推荐策略：${question.strategy}")
            }
        }
        Spacer(Modifier.weight(1f))
        Button(onClick = onAgain, modifier = Modifier.fillMaxWidth()) { Text("重新训练本题") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("回到首页") }
        Spacer(Modifier.navigationBarsPadding())
    }
}
