package com.zhiwu.olympiadtutor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.lifecycleScope
import com.zhiwu.olympiadtutor.data.AppDatabase
import com.zhiwu.olympiadtutor.data.ContentPackImporter
import com.zhiwu.olympiadtutor.data.OlympiadRepository
import com.zhiwu.olympiadtutor.ui.OlympiadApp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = AppDatabase.get(this)
        val repository = OlympiadRepository(db)
        val importer = ContentPackImporter(this, db)

        lifecycleScope.launch {
            val count = withContext(Dispatchers.IO) { db.questionDao().countOnce() }
            if (count == 0) runCatching { importer.importBuiltIn() }
        }

        setContent { OlympiadApp(repository = repository, importer = importer) }
    }
}
