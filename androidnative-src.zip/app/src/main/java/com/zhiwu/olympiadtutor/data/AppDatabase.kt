package com.zhiwu.olympiadtutor.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ContentPackEntity::class, QuestionEntity::class, ReasoningNodeEntity::class, AttemptEntity::class, MasteryEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun questionDao(): QuestionDao
    abstract fun reasoningNodeDao(): ReasoningNodeDao
    abstract fun packDao(): PackDao
    abstract fun learningDao(): LearningDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "olympiad_tutor_runtime.db"
            ).build().also { INSTANCE = it }
        }
    }
}
