package com.zhiwu.olympiadtutor.data

import android.content.Context
import android.net.Uri
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.util.zip.ZipInputStream

data class ImportResult(val bundleId: String, val title: String, val questionCount: Int, val tutorReadyCount: Int)

class ContentPackImporter(private val context: Context, private val db: AppDatabase) {
    suspend fun importBuiltIn(): ImportResult = withContext(Dispatchers.IO) {
        val root = JSONObject(context.assets.open("starter.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
        importJson(root.getJSONObject("manifest"), root.getJSONArray("questions"))
    }

    suspend fun importUri(uri: Uri): ImportResult {
        val input = context.contentResolver.openInputStream(uri) ?: error("无法打开题库包")
        input.use { return importZip(it) }
    }

    private suspend fun importZip(input: InputStream): ImportResult = withContext(Dispatchers.IO) {
        var manifestText: String? = null
        var questionsText: String? = null
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory) {
                    val bytes = zip.readBytes()
                    when (entry.name) {
                        "manifest.json" -> manifestText = bytes.toString(Charsets.UTF_8)
                        "questions.json" -> questionsText = bytes.toString(Charsets.UTF_8)
                    }
                }
                zip.closeEntry()
            }
        }
        importJson(
            JSONObject(manifestText ?: error("题库包缺少 manifest.json")),
            JSONArray(questionsText ?: error("题库包缺少 questions.json")),
        )
    }

    private suspend fun importJson(manifest: JSONObject, questions: JSONArray): ImportResult {
        val schemaVersion = manifest.getString("schema_version")
        require(schemaVersion == "0.2.0") { "不支持的题库 Schema：$schemaVersion" }
        val bundleId = manifest.getString("bundle_id")
        val title = manifest.getString("title")
        val bundleVersion = manifest.getString("bundle_version")
        val ontologyVersion = manifest.optString("ontology_version", "unknown")
        require(questions.length() == manifest.getInt("question_count")) { "题目数量与 manifest 不一致" }

        var tutorReady = 0
        db.withTransaction {
            db.reasoningNodeDao().deleteForBundle(bundleId)
            db.questionDao().deleteBundle(bundleId)
            db.packDao().delete(bundleId)

            for (i in 0 until questions.length()) {
                val q = questions.getJSONObject(i)
                val tier = q.optString("tier", "structured")
                if (tier == "tutor") tutorReady++
                val questionId = q.getString("id")
                db.questionDao().upsert(
                    QuestionEntity(
                        id = questionId, bundleId = bundleId, source = q.optString("source"),
                        title = q.getString("title"), family = q.optString("family", "未分类"),
                        strategy = q.optString("strategy", ""), difficulty = q.optString("difficulty", "未校准"),
                        tier = tier, answer = q.optString("answer", ""),
                    )
                )
                val nodes = q.optJSONArray("nodes") ?: JSONArray()
                for (n in 0 until nodes.length()) {
                    val node = nodes.getJSONObject(n)
                    db.reasoningNodeDao().upsert(
                        ReasoningNodeEntity(
                            questionId = questionId, ordinal = n, type = node.getString("type"),
                            prompt = node.getString("prompt"), payloadJson = node.toString(),
                            hint = node.optString("hint"), feedback = node.optString("feedback"),
                        )
                    )
                }
            }
            db.packDao().upsert(
                ContentPackEntity(
                    bundleId = bundleId, title = title, bundleVersion = bundleVersion,
                    schemaVersion = schemaVersion, ontologyVersion = ontologyVersion,
                    questionCount = questions.length(), tutorReadyCount = tutorReady,
                    importedAt = System.currentTimeMillis(),
                )
            )
        }
        return ImportResult(bundleId, title, questions.length(), tutorReady)
    }
}
