# Olympiad Tutor Android Native v0.2

- Kotlin + Jetpack Compose + Room
- 手机竖屏优先
- 内置 10 道 Tutor Ready 思路训练题（文本 starter.json）
- 支持从系统文件选择器导入 `.olympiadpack`
- 同一 bundle_id 更新只替换内容，不删除 attempts / mastery
- TutorEngine：只有明确提交并判定正确才推进节点
